package com.prakat.fever;

import java.util.ResourceBundle;

public class FeverDAO {
	private static ResourceBundle rb = ResourceBundle.getBundle("Fever");
	String node50=rb.getString("50");
	String node51=rb.getString("51");
	String node52=rb.getString("52");
	String node53=rb.getString("53");
	String node54=rb.getString("54");
	String node55=rb.getString("55");
	String node56=rb.getString("56");
	String node57=rb.getString("57");
	String node58=rb.getString("58");
	String node59=rb.getString("59");

	
	
	String node1=rb.getString("1");
	String node2=rb.getString("2");
	String node3=rb.getString("3");
	String node4=rb.getString("4");
	String node5=rb.getString("5");
	String node6=rb.getString("6");
	String node7=rb.getString("7");
	String node8=rb.getString("8");
	String node9=rb.getString("9");
	String node10=rb.getString("10");
	String node11=rb.getString("11");
	String node12=rb.getString("12");
	String node13=rb.getString("13");
	String node14=rb.getString("14");
	String node15=rb.getString("15");
	String node16=rb.getString("16");
	String node17=rb.getString("17");
	String node18=rb.getString("18");
	String node19=rb.getString("19");
	String node20=rb.getString("20");
	String node21=rb.getString("21");
	String node22=rb.getString("22");
	String node23=rb.getString("23");
	String node24=rb.getString("24");
	String node25=rb.getString("25");
	String node26=rb.getString("26");
	String node27=rb.getString("27");
	String node28=rb.getString("28");
	String node29=rb.getString("29");
	String node30=rb.getString("30");
	String node31=rb.getString("31");
	String node32=rb.getString("32");
	
	String node33=rb.getString("33");
	String node34=rb.getString("34");
	String node35=rb.getString("35");
	String node36=rb.getString("36");
	String node37=rb.getString("37");
	String node38=rb.getString("38");
	String node39=rb.getString("39");
	String node40=rb.getString("40");
	String node41=rb.getString("41");
	String node42=rb.getString("42");
	String node43=rb.getString("43");
	String node44=rb.getString("44");
	String node45=rb.getString("45");
	String node46=rb.getString("46");
	String node47=rb.getString("47");
	String node48=rb.getString("48");
	String node49=rb.getString("49");
	
}
