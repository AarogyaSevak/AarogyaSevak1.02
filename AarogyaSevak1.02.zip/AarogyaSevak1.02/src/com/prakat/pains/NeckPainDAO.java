package com.prakat.pains;

import java.util.ResourceBundle;

public class NeckPainDAO {
	private static ResourceBundle rb = ResourceBundle.getBundle("neckpain");
	String node1=rb.getString("1");
	String node2=rb.getString("2");
	String node3=rb.getString("3");
	String node4=rb.getString("4");
	String node5=rb.getString("5");
	String node6=rb.getString("6");
	String node7=rb.getString("7");
	String node8=rb.getString("8");
	String node9=rb.getString("9");
	String node10=rb.getString("10");
	String node11=rb.getString("11");
	String node12=rb.getString("12");
	String node13=rb.getString("13");
	String node14=rb.getString("14");
	String node15=rb.getString("15");
	String node16=rb.getString("16");
	String node17=rb.getString("17");
	String node18=rb.getString("18");
	String node19=rb.getString("19");
	String node20=rb.getString("20");
	String node21=rb.getString("21");
	String node22=rb.getString("22");
	String node23=rb.getString("23");
	String node24=rb.getString("24");
	String node25=rb.getString("25");
	String node26=rb.getString("26");
	String node27=rb.getString("27");
	String node28=rb.getString("28");
	String node29=rb.getString("29");
	String node30=rb.getString("30");
	String node31=rb.getString("31");
	String node32=rb.getString("32");
	String node33=rb.getString("33");
	String node34=rb.getString("34");
	
}
