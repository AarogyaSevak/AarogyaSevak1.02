package com.prakat.pains;

import java.util.ResourceBundle;

public class SwollenAnklesDAO {

	private static ResourceBundle rb = ResourceBundle.getBundle("swollenankles");
	String node1 = rb.getString("1");
	String node2 = rb.getString("2");
	String node3 = rb.getString("3");
	String node4 = rb.getString("4");
	String node5 = rb.getString("5");
	String node6 = rb.getString("6");
	String node7 = rb.getString("7");
	String node8 = rb.getString("8");
	String node9 = rb.getString("9");
	String node10 = rb.getString("10");
	String node11 = rb.getString("11");
	String node12 = rb.getString("12");
	String node13 = rb.getString("13");
	String node14 = rb.getString("14");
	String node15 = rb.getString("15");
	String node16 = rb.getString("16");
	String node17 = rb.getString("17");
	String node18 = rb.getString("18");

}
